function [X,G,Core,R,L] = DataSynttheticOdd(bench)

switch bench

    case 1 % 5D

        I = [10 10 10 10 10];
        R = [3,3,3];
        L = [5,5,5];
        
        G = cell([3,1]);
        G{1} = max(0,randn([R(1),I(1),I(2),L(1),R(2)]));
        G{2} = max(0,randn([R(2),I(3),I(4),L(2),R(3)]));
        G{3} = max(0,randn([R(3),I(5),L(3),R(1)]));        
        Core = max(0,randn([L]));

    case 2 % 7D

        I = [10 10 10 10 10 10 10];
        R = [3,3,3,3]; 
        L = [5,5,5,5]; 
        
        G = cell([4,1]);
        G{1} = max(0,randn([R(1),I(1),I(2),L(1),R(2)]));
        G{2} = max(0,randn([R(2),I(3),I(4),L(2),R(3)]));
        G{3} = max(0,randn([R(3),I(5),I(6),L(3),R(4)]));
        G{4} = max(0,randn([R(4),I(7),L(4),R(1)]));
        Core = max(0,randn([L]));
   
    case 3 % 9D

        I = [10 10 10 10 10 10 10 10 10];
        R = [3,3,3,3,3]; 
        L = [5,5,5,5,5]; 
        
        G = cell([4,1]);
        G{1} = max(0,randn([R(1),I(1),I(2),L(1),R(2)]));
        G{2} = max(0,randn([R(2),I(3),I(4),L(2),R(3)]));
        G{3} = max(0,randn([R(3),I(5),I(6),L(3),R(4)]));
        G{4} = max(0,randn([R(4),I(7),I(8),L(4),R(5)]));       
        G{5} = max(0,randn([R(5),I(9),L(5),R(1)]));
        Core = max(0,randn([L]));
   
end

% Create data
X = cores_prod(G,Core);

end

