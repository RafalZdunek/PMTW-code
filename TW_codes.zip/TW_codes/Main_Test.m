clear all

% ========================================================================
%% Model for data generation
% 1- CP, 2 - Tucker, 3 - TR, 4 - TW

bench = 4; 
%[Y,G,Core,R,L] = DataSynttheticOdd(bench);
%[Y,G,Core,R,L] = DataSynttheticEven(bench);
Y = DataBenchmark(bench);
DimY = size(Y);

R = [3 3 3]; L = [5 5 5];
MCruns = 1;
SNR = [];

% =========================================================================
%% Methods
% 1- PM-TW(svd), 2 - PM-TW(rand(Q2))
Methods = [1 2];

Labels_methods = {'PM-TW','rBKI-PM-TW(Q=2)'};

Structure_data.Methods=Methods;
Structure_data.labels=Labels_methods;
Structure_data.ranks=[R; L];
Structure_data.MC = MCruns;
Structure_data.SNR = SNR;
Structure_data.Y = Y;
Structure_data.show_inx = 1; 
Y = []; G = []; Core = [];

% Run methods
[RES,ET,Error_true,Error_fro,Error_spec,Error_ub] = TensorDecompMethods(Structure_data);

% =========================================================================
%% Output
Structure_data_output.bench = bench;
Structure_data_output.ranks = [R; L];
Structure_data_output.RES = RES;
Structure_data_output.ET = ET;
Structure_data_output.Error_true = Error_true;
Structure_data_output.Error_fro = Error_fro;
Structure_data_output.Error_spec = Error_spec;
Structure_data_output.Error_ub = Error_ub;

Results = table(mean(RES,2), mean(ET,2) ,'RowNames',Labels_methods(Methods),'VariableNames',{'Res. error','Runtime [sec.]'})

