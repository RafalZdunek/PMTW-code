function [G, C, Out] = TW_rnd(W, opts)

if isfield(opts, 'R');  R_max = opts.R;  end
if isfield(opts, 'method')  
    method = opts.method;  
else
    method = 1; % svd
end
if isfield(opts, 'Q')  
    Q = opts.Q;  
else
    Q = 0;
end
if isfield(opts, 'p')  
    p = opts.p;  
else
    p = 4;
end
if isfield(opts, 'err_show')  
    err_show = opts.err_show;  
else
    err_show = 0;
end

Ndim = ndims(W); % number of modes 
if Ndim < 3, error('Insufficient number of modes'); end

R = R_max(1,:); % outer ring ranks
L = R_max(2,:); % inner core ranks
K = ceil(ndims(W)/2); % number of modes in the inner core
G = cell([K,1]); % ring tensors
err_group = cell([K,1]);

for k = 1:K

    if k == 1
        
        DimW = size(W); Wdim = ndims(W);
        W_mtx = reshape(W,[DimW(1)*DimW(2), prod(DimW)/(DimW(1)*DimW(2))]); % unfolding 
      
        J = R(k)*L(k)*R(k+1);
        while size(W_mtx,1) < J % rank correction
           [~,inx_max] = max([R(k),R(k+1),L(k)]);
           if inx_max == 3
               L(k) = max(2,L(k) - 1);
           else
              R(inx_max) = max(2,R(inx_max) - 1);
           end
           J = R(k)*L(k)*R(k+1);
        end

        [U, W_tilde, err] = FeatureExtract(W_mtx,J,method,Q,p,err_show); % feature extraction
        err_group{k} = err;
      
        G{k} = permute(reshape(U(:,1:J), [DimW(k), DimW(k+1), R(k), L(k), R(k+1)]),[3, 1, 2, 4, 5]);
        W = permute(reshape(W_tilde,[R(k), L(k), R(k+1), DimW(3:end)]),[3:Wdim+1,1,2]); % tensor
 

    elseif k > 1 && k < K

        DimW = size(W); 
        W_mtx = reshape(W,[prod(DimW(1:3)), prod(DimW(4:end))]);
        DimW = size(W); Wdim = ndims(W);
  
        J = L(k)*R(k+1);
        while size(W_mtx,1) < J % rank correction
           [~,inx_max] = max([L(k),R(k+1)]);
           if inx_max == 1
               L(k) = max(2,L(k) - 1);
           else
               R(k+1) = max(2,R(k+1) - 1);
           end
           J = L(k)*R(k+1);
        end

        [U, W_tilde, err] = FeatureExtract(W_mtx,J,method,Q,p,err_show); % feature extraction
        err_group{k} = err;
      
        G{k} = reshape(U(:,1:J), [DimW(1:3), L(k), R(k+1)]);
        W = permute(reshape(W_tilde,[L(k), R(k+1), DimW(4:end)]),[2:Wdim-1,1]); 
      
    else

        DimW = size(W); 
        if ~mod(Ndim,2)
            W_mtx = reshape(W,[prod(DimW(1:4)), prod(DimW(5:end))]);
        else
            W_mtx = reshape(W,[prod(DimW(1:3)), prod(DimW(4:end))]);
        end

        J = L(k);
        while size(W_mtx,1) < J
              L(k) = max(2,L(k) - 1);
        end
        [U, W_tilde, err] = FeatureExtract(W_mtx,J,method,Q,p,err_show); % feature extraction
        err_group{k} = err;

        
        if ~mod(Ndim,2) 
            G{k} = permute(reshape(U(:,1:J), [DimW(1:4), L(k)]),[1, 2, 3, 5, 4]);
            C = permute(reshape(W_tilde,[L(k),L(1:k-1)]),[2:K,1]);
        else
            G{k} = permute(reshape(U(:,1:J), [DimW(1:3), L(k)]),[1, 2, 4, 3]);
            C = permute(reshape(W_tilde,[L(k),L(1:k-1)]),[2:K,1]);     
        end
  

    end % if

end % k

function [U, W_tilde,err] = FeatureExtract(W_mtx,J,method,Q,p,err_show) 

    err = [];

    switch method

        case 1 % SVD

            [U,S,V] = svd(W_mtx,'econ');
            W_tilde = (V(:,1:J)*S(1:J,1:J))';

            if err_show
               s = diag(S); 
               err.true = norm((eye(size(U,1)) - U(:,1:J)*U(:,1:J)')*W_mtx)^2;
               if length(s) > J
                  err.fro_2 = sum(s(J+1:end).^2);  
                  err.spec_2 = sum(s(J+1).^2);  
               else
                 err.fro_2 = 0;
                 err.spec_2 = 0;
               end
            end

        case 2 % rand

            if size(W_mtx,2) > 2*size(W_mtx,1)

            J_tilde = J + p;
            Omega = randn(size(W_mtx,2),J_tilde);
            W_bar = W_mtx*W_mtx';
            W_hat = W_mtx*Omega;
            B = W_hat;
            for q = 1:Q
                B = [W_bar*B, B];
            end
            [Q_qr,~] = qr(B,0);
            Qt = Q_qr(:,1:J_tilde);
            Z = Qt'*W_bar*Qt;
            [U_tilde,~,~] = svd(Z);
            U = Qt*U_tilde(:,1:J);
            W_tilde = U'*W_mtx; 

            if err_show
               s = svd(W_mtx); 
               nu = (1 - s.^(4*(Q+1)))./(1 - s.^4);
               err.true = norm((eye(size(Qt,1)) - Qt*Qt')*W_mtx)^2;               
               if length(s) > J
                  err.ub_2 = (s(J+1)*(1+sqrt(J)/(p -1)) + (exp(1)*sqrt(J+p)/(p*sqrt(nu(J+1))))*sqrt(sum(nu(J+1:end).*s(J+1:end).^2)))^2;            
               else
                  err.ub_2 = 0;
               end % if
            end

            else % if

            [U,S,V] = svd(W_mtx,'econ');
            W_tilde = (V(:,1:J)*S(1:J,1:J))';

            if err_show
               Q1 = U(:,1:J);      
               err.true = norm((eye(size(Q1,1)) - Q1*Q1')*W_mtx)^2;
               err.ub_2 = err.true; 
            end

            end % if

        case 3 % Power method

             if size(W_mtx,2) > 2*size(W_mtx,1)

                J_tilde = J + p;
                Omega = randn(size(W_mtx,2),J_tilde);
                W_bar = W_mtx*W_mtx';
                B = W_mtx*Omega;
                B = W_bar*B;  
                B = W_bar*B;
                [Q_qr,~] = qr(B,0);
                Qt = Q_qr(:,1:J_tilde);
                Z = Qt'*W_bar*Qt;
                [U_tilde,~,~] = svd(Z);
                U = Qt*U_tilde(:,1:J);
                W_tilde = U'*W_mtx; 
        
                if err_show
                   s = svd(W_mtx);       
                  % err.true = 0;
                   err.true = (norm((eye(size(U,1)) - U*U')*W_mtx))^2;
                   if length(s) > J
                      err.ub_2 = ( (1 + sqrt(J/(p-1)))*s(J+1)^(2*Q+1) + (exp(1)*sqrt(J+p)/p)*sqrt( sum(s(J+1:end).^(4*Q+2)) )  )^(2/(2*Q+1));                       
                   else
                      err.ub_2 = 0;
                   end % if
                end

             else

             [U,S,V] = svd(W_mtx,'econ');
             W_tilde = (V(:,1:J)*S(1:J,1:J))';

             if err_show
                Q1 = U(:,1:J);    
                err.true = norm((eye(size(Q1,1)) - Q1*Q1')*W_mtx)^2;
                err.ub_2 = err.true; 
             end

             end % if


    end % switch

end % function

Out.rse = [];
Out.Rnew = [R; L]; 
Out.error = err_group;

end
