function [RES,ET,Error_true,Error_fro,Error_spec,Error_ub] = TensorDecompMethods(Structure_data)

Z=length(Structure_data.Methods);
Nsnr = max(1,length(Structure_data.SNR));
RES = zeros(Z,Nsnr,Structure_data.MC);
Error_true = zeros(Z,Nsnr,Structure_data.MC);
Error_fro = zeros(Z,Nsnr,Structure_data.MC);
Error_spec = zeros(Z,Nsnr,Structure_data.MC);
Error_ub = zeros(Z,Nsnr,Structure_data.MC);
ET = zeros(Z,Nsnr,Structure_data.MC); 
Ynorm = norm(Structure_data.Y(:));

for k = 1:Structure_data.MC

    for n = 1:Nsnr

        if ~isempty(Structure_data.SNR)
            Nt = randn(size(Structure_data.Y)); 
            tau = (norm(Structure_data.Y(:))/norm(Nt(:)))*10^(-Structure_data.SNR(n)/20);
            Yn = Structure_data.Y + tau*Nt;
        else
            Yn = Structure_data.Y;
        end

        for w = 1:Z
            if(Structure_data.show_inx==1)
                if (k < 2) || ~mod(k,1)
                    if ~isempty(Structure_data.SNR)    
                        disp(['Method: ',num2str(Structure_data.Methods(w)), ', SNR = ',num2str(Structure_data.SNR(n)),', MCrun: ',num2str(k)]);                        
                    else
                        disp(['Method: ',num2str(Structure_data.Methods(w)),', MCrun: ',num2str(k)]);       
                    end

                end
            end
            
            switch Structure_data.Methods(w)
                
                case 1 % PM-TW
                                   
                    opts.R = circshift(Structure_data.ranks,[0,0]);
                    opts.p = 4; % oversampling parameter
                    opts.Q = 2; % Q-randomization
                    opts.method =   1; % 1- svd, 2 - rBKI, 3 - Power
                    opts.err_show = 1; % 1 - show info, 0 - no info
    
                    tic
                        [Gestim, C, Out] = TW_rnd(Yn, opts);
                    ET(w,n,k) = toc;
    
                    Yestim = cores_prod(Gestim,C); 
                    RES(w,n,k) = norm(Structure_data.Y(:)-Yestim(:)) / Ynorm;
                    if opts.err_show
                        T = cell2mat(Out.error);
                        Error_true(w,n,k) = sqrt(sum([T.true]))/Ynorm;
                        Error_fro(w,n,k) = sqrt(sum([T.fro_2]))/Ynorm;
                        Error_spec(w,n,k) = sqrt(sum([T.spec_2]))/Ynorm;
                    end                                   
                         
                case 2 % rBKI-PM-TW(Q=2)
                    
                    opts.R = circshift(Structure_data.ranks,[0,0]);
                    opts.p = 4; % oversampling parameter
                    opts.Q = 2; % Q-randomization
                    opts.method =   2; % 1- svd, 2 - rBKI, 3 - Power
                    opts.err_show = 1; % 1 - show info, 0 - no info
    
                    tic
                        [Gestim, C, Out] = TW_rnd(Yn, opts);
                    ET(w,n,k) = toc;
    
                    Yestim = cores_prod(Gestim,C);                   
                    RES(w,n,k) = norm(Structure_data.Y(:)-Yestim(:)) / Ynorm;
                    if opts.err_show
                        T = cell2mat(Out.error);
                        Error_true(w,n,k) = sqrt(sum([T.true]))/Ynorm;
                        Error_ub(w,n,k) = sqrt(sum([T.ub_2]))/Ynorm;
                    end
                                           
                otherwise
                    error('Wrong method number!')
                    
            end % switch     
          
            
        end % for w

    end % for n
    
    
end % for k


end
