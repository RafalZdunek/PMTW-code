function X = cores_prod(G,C)

    Nc = length(G);
    X = tensorprod(G{1},C,4,1);
    X = permute(X,[5:Nc+3,1:4]);

    for n = 1:Nc-2
        X = tensorprod(X,G{n+1},[1,Nc+2+n],[4,1]);
    end
    if  mod(ndims(G{Nc}),2)
        X = tensorprod(X,G{Nc},[1, 2, 2*Nc+1],[4, 5, 1]);
    else
        X = tensorprod(X,G{Nc},[1, 2, 2*Nc+1],[3, 4, 1]);
    end

end